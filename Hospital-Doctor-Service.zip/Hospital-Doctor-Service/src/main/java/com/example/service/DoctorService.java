package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.example.entity.Appointment;
import com.example.entity.Doctor;
import com.example.entity.Patient;
import com.example.externalservice.AppointmentFeignClient;
import com.example.externalservice.PatientFeignClient;
import com.example.repository.DoctorRepository;

import java.util.List;
import java.util.Optional;

@Service
public class DoctorService {
    @Autowired
    private DoctorRepository doctorRepository;
    
    @Autowired
    private PatientFeignClient patientFeignClient;
    
    @Autowired
    private AppointmentFeignClient appointmentFeignClient;

    public Doctor registerDoctor(Doctor doctor) {
        return doctorRepository.save(doctor);
    }
    
    public Optional<Doctor> getDoctorById(Long docterId) {
        return doctorRepository.findById(docterId);
    }

    public List<Doctor> getPendingApprovalDoctors() {
        return doctorRepository.findByApproved(false);
    }

    public void approveDoctor(Long doctorId) {
        Doctor doctor = doctorRepository.findById(doctorId).orElse(null);
        if (doctor != null) {
            doctor.setApproved(true);
            doctorRepository.save(doctor);
        }
    }

    public void rejectDoctor(Long doctorId) {
        doctorRepository.deleteById(doctorId);
    }

    public List<Doctor> getAllDoctors() {
        return doctorRepository.findAll();
    }
    
    public Patient getPatientById(Long patientId) {
        // Use the Feign client to fetch patient data from the Patient Service
        return patientFeignClient.getPatientById(patientId);
    }
    
    public Appointment getAppointmentById(Long appointmentId) {
        return appointmentFeignClient.getAppointmentById(appointmentId);
    }
}
