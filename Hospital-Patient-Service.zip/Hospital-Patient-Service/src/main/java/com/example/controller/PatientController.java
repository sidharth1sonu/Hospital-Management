package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.entity.Appointment;
import com.example.entity.Patient;
import com.example.externalservice.AppointmentFeignClient;
import com.example.externalservice.DoctorClient;
import com.example.service.PatientService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/patients")
public class PatientController {
    @Autowired
    private PatientService patientService;

    @Autowired
    private DoctorClient doctorClient; // Inject the DoctorClient
    
    @Autowired
    private AppointmentFeignClient appointmentFeignClient;

    @PostMapping("/register")
    public Patient registerPatient(@RequestBody Patient patient) {
        return patientService.registerPatient(patient);
    }

    @GetMapping("/pending-approval")
    public List<Patient> getPendingApprovalPatients() {
        return patientService.getPendingApprovalPatients();
    }

    @PostMapping("/approve/{patientId}")
    public ResponseEntity<String> approvePatient(@PathVariable Long patientId) {
        patientService.approvePatient(patientId);
        return ResponseEntity.status(HttpStatus.OK).body("Patient approved successfully.");
    }

    @DeleteMapping("/reject/{patientId}")
    public ResponseEntity<String> rejectPatient(@PathVariable Long patientId) {
        patientService.rejectPatient(patientId);
        return ResponseEntity.status(HttpStatus.OK).body("Patient rejected successfully.");
    }

    @GetMapping("/all")
    public List<Patient> getAllPatients() {
        return patientService.getAllPatients();
    }

    @PostMapping("/book-appointment/{patientId}/{doctorId}")
    public ResponseEntity<String> bookAppointment(
            @PathVariable Long patientId,
            @PathVariable Long doctorId
    ) {
        patientService.bookAppointment(patientId, doctorId);
        return ResponseEntity.status(HttpStatus.OK).body("Appointment booked successfully.");
    }

    @GetMapping("/discharged")
    public List<Patient> getDischargedPatients() {
        return patientService.getDischargedPatients();
    }

    // New endpoint to test the DoctorClient
    @GetMapping("/doctors")
    public ResponseEntity<String> testFeignClient(@RequestParam Long docterId) {
        // Use the DoctorClient to fetch doctor data
        return doctorClient.getDoctorById(docterId)
                .map(doctor -> ResponseEntity.ok("Doctor data: " + doctor.toString()))
                .orElse(ResponseEntity.notFound().build());
    }
    
    @GetMapping("/{patientId}")
    public ResponseEntity<Patient> getPatientById(@PathVariable Long patientId) {
        Optional<Patient> patient = patientService.getPatientById(patientId);
        if (patient.isPresent()) {
            return ResponseEntity.ok(patient.get());
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }
    
    
    @GetMapping("/view-appointment/{appointmentId}")
    public ResponseEntity<Object> viewAppointment(@PathVariable Long appointmentId) {
        Appointment appointment = patientService.getAppointmentById(appointmentId);

        if (appointment != null) {
            return ResponseEntity.ok(appointment);
        } else {
            return ResponseEntity.notFound().build();
        }
}

}
