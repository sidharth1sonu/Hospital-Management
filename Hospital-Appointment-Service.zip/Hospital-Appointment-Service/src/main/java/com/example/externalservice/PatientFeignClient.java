package com.example.externalservice;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.entity.Patient;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient(name = "Patient-Service")
public interface PatientFeignClient {

    @Retry(name = "Patient-Service")
    @CircuitBreaker(name = "Patient-Service", fallbackMethod = "fallbackMethodGetPatientById")
    @GetMapping(value = "/patients/{patientId}", produces = { MediaType.APPLICATION_JSON_VALUE })
    Patient getPatientById(@PathVariable("patientId") Long patientId);

    // Add any additional methods for the Patient service here if needed

    default Patient fallbackMethodGetPatientById(Long patientId, Throwable cause) {
        System.out.println("Exception raised with message: " + cause.getMessage());
        // Create a default message to indicate that no patients are available
        Patient defaultPatient = new Patient();
        defaultPatient.setPatientId(patientId);
        defaultPatient.setName("No Patients Available");
        defaultPatient.setMobile("N/A");
        defaultPatient.setApproved(false);
        defaultPatient.setAssignedDoctorId(null);
        defaultPatient.setDischarged(false);

        return defaultPatient;
    }
}