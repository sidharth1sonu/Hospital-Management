package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.entity.Appointment;
import com.example.entity.Doctor;
import com.example.entity.Patient;
import com.example.externalservice.AppointmentFeignClient;
import com.example.externalservice.PatientFeignClient;
import com.example.service.DoctorService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/doctors")
public class DoctorController {
    @Autowired
    private DoctorService doctorService;
    
    @Autowired
    private PatientFeignClient patientFeignClient;
    
    @Autowired
    private AppointmentFeignClient appointmentFeignClient;

    @PostMapping("/register")
    public Doctor registerDoctor(@RequestBody Doctor doctor) {
        return doctorService.registerDoctor(doctor);
    }
    
    @GetMapping("/{docterId}")
    public Optional<Doctor> getDoctorById(@PathVariable Long docterId) {
      return  doctorService.getDoctorById(docterId);
      
    }

    @GetMapping("/pending-approval")
    public List<Doctor> getPendingApprovalDoctors() {
        return doctorService.getPendingApprovalDoctors();
    }

    @PostMapping("/approve/{doctorId}")
    public ResponseEntity<String> approveDoctor(@PathVariable Long doctorId) {
        doctorService.approveDoctor(doctorId);
        return ResponseEntity.status(HttpStatus.OK).body("Doctor approved successfully.");
    }

    @DeleteMapping("/reject/{doctorId}")
    public ResponseEntity<String> rejectDoctor(@PathVariable Long doctorId) {
        doctorService.rejectDoctor(doctorId);
        return ResponseEntity.status(HttpStatus.OK).body("Doctor rejected successfully.");
    }

    @GetMapping("/all")
    public List<Doctor> getAllDoctors() {
        return doctorService.getAllDoctors();
    }
    
    @GetMapping("/patient/{patientId}")
    public Patient checkFeignClient(@PathVariable Long patientId) {
        // Call the Feign client to retrieve patient information
        return patientFeignClient.getPatientById(patientId);
    }
    
    @GetMapping("/view-appointment/{appointmentId}")
    public ResponseEntity<Object> viewAppointment(@PathVariable Long appointmentId) {
        Appointment appointment = doctorService.getAppointmentById(appointmentId);

        if (appointment != null) {
            return ResponseEntity.ok(appointment);
        } else {
            return ResponseEntity.notFound().build();
        }
}
}
