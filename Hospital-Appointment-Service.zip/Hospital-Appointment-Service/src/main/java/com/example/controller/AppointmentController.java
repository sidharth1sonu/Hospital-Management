package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.entity.Appointment;
import com.example.entity.Patient;
import com.example.externalservice.DoctorClient;
import com.example.externalservice.PatientFeignClient;
import com.example.service.AppointmentService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/appointments")
public class AppointmentController {
    @Autowired
    private AppointmentService appointmentService;
    @Autowired
    private PatientFeignClient patientFeignClient;
    
    @Autowired
    private DoctorClient doctorClient;

    @PostMapping("/create")
    public Appointment createAppointment(@RequestBody Appointment appointment) {
        return appointmentService.createAppointment(appointment);
    }

//    @GetMapping("/patient/{patientId}")
//    public List<Appointment> getAppointmentsByPatient(@PathVariable Long patientId) {
//        return appointmentService.getAppointmentsByPatient(patientId);
//    }

    @GetMapping("/doctor/{doctorId}")
    public List<Appointment> getAppointmentsByDoctor(@PathVariable Long doctorId) {
        return appointmentService.getAppointmentsByDoctor(doctorId);
    }

    @GetMapping("/pending-approval")
    public List<Appointment> getPendingApprovalAppointments() {
        return appointmentService.getPendingApprovalAppointments();
    }

    @PostMapping("/approve/{appointmentId}")
    public ResponseEntity<String> approveAppointment(@PathVariable Long appointmentId) {
        appointmentService.approveAppointment(appointmentId);
        return ResponseEntity.status(HttpStatus.OK).body("Appointment approved successfully.");
    }
    
    
    @GetMapping("/{appointmentId}")
    public ResponseEntity<Object> getAppointmentById(@PathVariable Long appointmentId) {
        Optional<Appointment> optionalAppointment = appointmentService.getAppointmentById(appointmentId);

        if (optionalAppointment.isPresent()) {
            Appointment appointment = optionalAppointment.get();
            return ResponseEntity.ok(appointment);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    

    @DeleteMapping("/reject/{appointmentId}")
    public ResponseEntity<String> rejectAppointment(@PathVariable Long appointmentId) {
        appointmentService.rejectAppointment(appointmentId);
        return ResponseEntity.status(HttpStatus.OK).body("Appointment rejected successfully.");
    }

    @GetMapping("/all")
    public List<Appointment> getAllAppointments() {
        return appointmentService.getAllAppointments();
    }
    
    
    @GetMapping("/patient/{patientId}")
    public Patient checkFeignClient(@PathVariable Long patientId) {
        // Call the Feign client to retrieve patient information
        return patientFeignClient.getPatientById(patientId);
    }
    
    // New endpoint to test the DoctorClient
    @GetMapping("/doctors")
    public ResponseEntity<String> testFeignClient(@RequestParam Long docterId) {
        // Use the DoctorClient to fetch doctor data
        return doctorClient.getDoctorById(docterId)
                .map(doctor -> ResponseEntity.ok("Doctor data: " + doctor.toString()))
                .orElse(ResponseEntity.notFound().build());
    }
}