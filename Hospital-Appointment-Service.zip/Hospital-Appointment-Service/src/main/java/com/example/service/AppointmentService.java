package com.example.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.Appointment;
import com.example.entity.Doctor;
import com.example.entity.Patient;
import com.example.externalservice.DoctorClient;
import com.example.externalservice.PatientFeignClient;

import com.example.repository.AppointmentRepository;

@Service
public class AppointmentService {
    @Autowired
    private AppointmentRepository appointmentRepository;
    
    @Autowired
    private PatientFeignClient patientFeignClient;
    
    @Autowired
    private DoctorClient doctorClient;

//    public List<Appointment> getAppointmentsByPatient(Long patientId) {
//        return appointmentRepository.findByPatientId(patientId);
//    }

    public List<Appointment> getAppointmentsByDoctor(Long doctorId) {
        return appointmentRepository.findByDoctorId(doctorId);
    }

    public List<Appointment> getPendingApprovalAppointments() {
        return appointmentRepository.findByApproved(false);
    }

    public void approveAppointment(Long appointmentId) {
        Appointment appointment = appointmentRepository.findById(appointmentId).orElse(null);
        if (appointment != null) {
            appointment.setApproved(true);
            appointmentRepository.save(appointment);
        }
    }

    public void rejectAppointment(Long appointmentId) {
        appointmentRepository.deleteById(appointmentId);
    }

    public List<Appointment> getAllAppointments() {
        return appointmentRepository.findAll();
    }
    
    public Appointment createAppointment(Appointment appointment) {
        // Your logic to create an appointment

        // Example of using the Feign client to get patient information
        Long patientId = appointment.getPatientId();
        Patient patient = patientFeignClient.getPatientById(patientId);


        return appointmentRepository.save(appointment);
    }
    
    public Optional<Appointment> getAppointmentById(Long appointmentId) {
        return appointmentRepository.findById(appointmentId);
    }

    // Fetch doctor information using the Feign client
    public Optional<Doctor> getDoctorById(Long docterId) {
        return doctorClient.getDoctorById(docterId);
    }

    public Patient getPatientById(Long patientId) {
        // Use the Feign client to fetch patient data from the Patient Service
        return patientFeignClient.getPatientById(patientId);
    }
}

